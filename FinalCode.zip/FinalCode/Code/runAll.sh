#!/bin/bash
# run griding.py and Holo_Multi.run
# change the input file acordingly

python griding.py PythonInput.param

./Holo_Multi.run 

